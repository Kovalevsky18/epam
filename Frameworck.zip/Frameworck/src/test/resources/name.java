<!DOCTYPE suite SYSTEM "http://testng.org/testng-1.0.dtd" >

<suite name="Smoke" verbose="1" >
    <test name="UserAccess"   >
        <classes>
            <class name="com.epam.ta.test.UserAccessTests" />
        </classes>
    </test>
</suite>