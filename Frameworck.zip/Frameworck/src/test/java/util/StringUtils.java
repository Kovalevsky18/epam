package util;

public class StringUtils {
    public static final String ERROR_MESSAGE = "Пожалуйста, введите данные";
    public static final String ERROR_MESSAGE_WITH_DATA = "Пожалуйста, подтвердите, что вы не робот.";
    public static final String CHANGED_CURRENCY = "$";
    public static final String ERROR_SEARCH_MESSAGE = "Пожалуйста, выберите место/отель для начала поиска.";
    public static final String INFO_ABOUT_RUSSIA_TEXT = "Курорты России";
}
